package org.contraApp;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.nio.file.Paths;
import java.text.Normalizer;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Iterator;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    private static final String PASTA_CONTRACHEQUES = "contracheques";

    public static void main(String[] args) throws InterruptedException {
        configurarWebDriver();

        WebDriver driver = iniciarChromeComPerfil();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        driver.get("https://web.whatsapp.com");

        System.out.println("🚀 Escaneie o QR Code do WhatsApp Web e pressione Enter...");
        new Scanner(System.in).nextLine();

        enviarContracheques(driver, wait);

        driver.quit();
        System.out.println("🏁 Processo finalizado.");
    }

    private static void configurarWebDriver() {
        WebDriverManager.chromedriver().setup();
    }

    private static WebDriver iniciarChromeComPerfil() {
        String perfilPath = Paths.get(System.getProperty("user.home"), "chrome-profile-envio").toString();
        new File(perfilPath).mkdirs();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("user-data-dir=" + perfilPath);
        return new ChromeDriver(options);
    }

    private static void enviarContracheques(WebDriver driver, WebDriverWait wait) {
        LocalDate data = LocalDate.now().minusMonths(1);
        String nomeMes = data.getMonth().getDisplayName(TextStyle.FULL, new Locale("pt", "BR"));
        int ano = data.getYear();

        try (InputStream is = Main.class.getResourceAsStream("/funcionarios.xlsx");
             Workbook workbook = new XSSFWorkbook(is)) {

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rows = sheet.iterator();
            if (rows.hasNext()) rows.next(); // pula cabeçalho

            while (rows.hasNext()) {
                Row row = rows.next();
                String nome = getCellValue(row.getCell(0));
                String telefone = getCellValue(row.getCell(1)).replaceAll("[^0-9]", "");

                if (nome.isBlank() || telefone.length() < 10) continue;

                String nomeArquivo = normalizar(nome) + ".pdf";
                File arquivo = Paths.get(PASTA_CONTRACHEQUES, nomeArquivo).toFile();

                if (!arquivo.exists()) {
                    System.out.println("❌ Arquivo não encontrado: " + arquivo.getAbsolutePath());
                    continue;
                }

                System.out.println("📨 Enviando para " + nome + " - " + telefone);
                enviarParaContato(driver, wait, nome, telefone, arquivo, nomeMes, ano);
            }

        } catch (Exception e) {
            System.err.println("❌ Falha ao processar planilha: " + e.getMessage());
        }
    }

    private static void enviarParaContato(WebDriver driver, WebDriverWait wait, String nome, String telefone, File arquivoPDF, String mes, int ano) throws InterruptedException {
        driver.get("https://web.whatsapp.com/send?phone=55" + telefone);

        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'copyable-text')]")));
            Thread.sleep(2000);

            boolean anexoEnviado = false;

            // Envia anexo
            try {
                By botaoAnexar = By.xpath("//span[@data-icon='plus-rounded' or @data-icon='clip']");
                wait.until(ExpectedConditions.elementToBeClickable(botaoAnexar)).click();
                Thread.sleep(1000);

                WebElement input = driver.findElement(By.xpath("//input[@type='file']"));
                input.sendKeys(arquivoPDF.getAbsolutePath());
                Thread.sleep(3000);

                WebElement botaoEnviar = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//div[@role='button' and @aria-label='Enviar']")));
                botaoEnviar.click();

                anexoEnviado = true;
                System.out.println("📎 Anexo enviado para " + nome);

                // Espera até o campo de mensagem voltar
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@contenteditable='true' and @aria-label='Digite uma mensagem']")));
                Thread.sleep(1000);

            } catch (Exception eAnexo) {
                System.err.println("⚠️ Falha ao anexar para " + nome + ": " + eAnexo.getMessage());
            }

            // Envia mensagem com tentativa em loop
            String mensagem = "Olá " + nome + ", este é o seu contracheque de " + mes + " de " + ano + ". Qualquer dúvida, fale com o RH.";
            boolean mensagemEnviada = false;
            int tentativas = 0;

            while (!mensagemEnviada && tentativas < 3) {
                try {
                    WebElement caixaTexto = wait.until(ExpectedConditions.elementToBeClickable(
                            By.xpath("//div[@contenteditable='true' and @aria-label='Digite uma mensagem']")));
                    caixaTexto.sendKeys(mensagem);
                    caixaTexto.sendKeys(Keys.ENTER);
                    mensagemEnviada = true;
                } catch (Exception eMsg) {
                    tentativas++;
                    Thread.sleep(1000);
                }
            }

            if (mensagemEnviada) {
                if (anexoEnviado) {
                    System.out.println("✅ Mensagem e anexo enviados para " + nome);
                } else {
                    System.out.println("✅ Apenas mensagem enviada para " + nome);
                }
            } else {
                System.err.println("❌ Falha ao enviar mensagem para " + nome);
            }

            Thread.sleep(2000);

        } catch (Exception e) {
            System.err.println("⚠️ Erro geral ao enviar para " + nome + ": " + e.getMessage());
        }
    }

    private static String getCellValue(Cell cell) {
        if (cell == null) return "";
        return cell.getCellType() == CellType.STRING ? cell.getStringCellValue().trim()
                : String.valueOf((long) cell.getNumericCellValue()).trim();
    }

    private static String normalizar(String texto) {
        return Normalizer.normalize(texto, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "")
                .toLowerCase()
                .trim()
                .replaceAll("[^a-z0-9]", " ");
    }
}
